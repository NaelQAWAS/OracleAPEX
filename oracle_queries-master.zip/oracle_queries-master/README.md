# oracle_queries
Oracle Queries
